
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;

public class gui extends Application{
	private Button vypis_kandidatov = new Button("Zoznam kandidátov");
	private Button hlasovanie = new Button("Hlasovanie");
	private Button vypis_celkovych_vysledkov=new Button ("Celkové výsledky volieb");
	private Button vypis_podla_krajov = new Button ("Výsledky volieb v jednotlivých krajoch");
	private Button vypis_podla_stran = new Button ("Výsledky volieb podľa príslušnosti k stranám");
	
	private ScrollPane scroll = new ScrollPane(); //zatial nepouzite
	private TextArea output = new TextArea();
	
	public void start(Stage mainWindow) throws FileNotFoundException {
		Vytvorenie_poli vytvorenie_poli = new Vytvorenie_poli();
	    vytvorenie_poli.vytvorenie_kandidatov();
	    vytvorenie_poli.vytvorenie_poslancov();
	    List<Kandidat> kandidati = vytvorenie_poli.getKandidati();
	    List<Poslanec> poslanci = vytvorenie_poli.getPoslanci();
		
		Volby volby=new Volby(kandidati,poslanci);
		
		mainWindow.setTitle("Voľby");
		FlowPane pane = new FlowPane();
		
		pane.getChildren().add(vypis_kandidatov);
		pane.getChildren().add(hlasovanie);
		pane.getChildren().add(vypis_celkovych_vysledkov);
		pane.getChildren().add(vypis_podla_krajov);
		pane.getChildren().add(vypis_podla_stran);
		
		scroll.setContent(pane);
		
		vypis_kandidatov.setOnAction(e->{
			volby.vypisKandidatov();
		}
		);
		
		hlasovanie.setOnAction(e->{
			volby.hlasovanie();
		});
		
		vypis_celkovych_vysledkov.setOnAction(e->{
			volby.vypisCelkoveVysledky();
		});
		
		vypis_podla_krajov.setOnAction(e->{
			volby.vypisVysledky_v_krajoch();
		});
		
		vypis_podla_stran.setOnAction(e->{
			volby.vypisVysledky_v_stranach();
		});
		
		mainWindow.setScene(new Scene(scroll, 500, 300));
		mainWindow.show();
	}
	
	public static void main(String[] args) {
		launch(args);
	}
}
