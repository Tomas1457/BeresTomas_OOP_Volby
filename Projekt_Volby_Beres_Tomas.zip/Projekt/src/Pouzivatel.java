//zatial nevyuzita trieda 
/*
class Pouzivatel extends Poslanec {
    private int vek;
    
    String datum_narodenia; //treba uviest bud datum narodenia alebo vek

    public Pouzivatel(String meno, int vek, String kraj, String strana) {
        super(meno, kraj, strana);
        this.vek = vek;
    }

    public int getVek() {
        return vek;
    }
}
*/