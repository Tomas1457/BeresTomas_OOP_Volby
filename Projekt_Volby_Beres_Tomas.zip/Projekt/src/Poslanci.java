
class Poslanec {
    protected String meno;
    protected String kraj;
    protected String strana;

    public Poslanec(String meno, String kraj, String strana) {
        this.meno = meno;
        this.kraj = kraj;
        this.strana = strana;
    }

    public void volim(Kandidat kandidat) {
        //System.out.println(meno + " hlasuje pre kandidáta: " + kandidat.getMeno());
        kandidat.inkrementujHlasy(kraj,strana);
    }
}
