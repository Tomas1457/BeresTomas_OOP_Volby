
class Prezident extends Zupan {
    private int pocetVolenychKandidatov;

    public Prezident(String meno, String kraj, String strana, int silaHlasu, int pocetVolenychKandidatov) {
        super(meno, kraj, strana);
        this.pocetVolenychKandidatov = pocetVolenychKandidatov;
        this.sila_hlasu = silaHlasu;
    }
    
    public void volim(Kandidat kandidat) {
    	for (int i=0;i<pocetVolenychKandidatov;i++) {
    		for (int j=0;j<getSilaHlasu();j++) {
    			kandidat.inkrementujHlasy(kraj,strana);
    		}
    	}
    }
}