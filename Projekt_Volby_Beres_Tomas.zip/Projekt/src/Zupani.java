
class Zupan extends Poslanec {
    
    private SilaHlasu silaHlasu;
    
    protected long sila_hlasu;
    
   
    public Zupan(String meno, String kraj, String strana) {
        super(meno, kraj, strana);
        silaHlasu=new SilaHlasu();
        sila_hlasu=silaHlasu.vypocitanie_sily(kraj);
    }
     
    
    public void volim(Kandidat kandidat) {
        for (int i=0;i<sila_hlasu;i++)
    		kandidat.inkrementujHlasy(kraj,strana);
    }

    public long getSilaHlasu() {
        return sila_hlasu;
    }
}