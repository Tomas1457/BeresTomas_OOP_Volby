import java.util.*;

class Volby {
    private List<Kandidat> kandidati;
    private List<Poslanec> poslanci;

    public Volby(List<Kandidat> kandidati, List<Poslanec> poslanci) {
        this.kandidati = kandidati;
        this.poslanci = poslanci;
    }

    public void hlasovanie() {
        for (Poslanec poslanec : poslanci) {
            Kandidat kandidat = vyberNahodnehoKandidata();
            poslanec.volim(kandidat);
        }
    }

    private Kandidat vyberNahodnehoKandidata() {
        Random random = new Random();
        int index = random.nextInt(kandidati.size());
        return kandidati.get(index);
    }

    public void vypisCelkoveVysledky() {
        System.out.println("Celkové výsledky volieb:");
        for (Kandidat kandidat : kandidati) {
            System.out.println(kandidat.getMeno() + ": " + kandidat.getPocetHlasov() + " hlasov");
        }
    }
    
    public void vypisVysledky_v_krajoch() {
    	
    	for (int i=0;i<8;i++) {
    		System.out.println("\n");
    		String kraj="BA";
    		switch (i) {
    		case 0: System.out.println("Výsledky volieb v Bratislavskom kraji:");
    				kraj="BA";
    				break;
    		case 1: System.out.println("Výsledky volieb v Trnavskom kraji:");
    				kraj="TT";
    				break;
    		case 2: System.out.println("Výsledky volieb v Nitrianskom kraji:");
    				kraj="NR";
    				break;
    		case 3: System.out.println("Výsledky volieb v Trenčianskom kraji:");
    				kraj="TN";
    				break;
    		case 4: System.out.println("Výsledky volieb v Žilinskom kraji:");
    				kraj="ZA";
    				break;
    		case 5: System.out.println("Výsledky volieb v Banskobystrickom kraji:");
    				kraj="BB";
    				break;
    		case 6: System.out.println("Výsledky volieb v Prešovskom kraji:");
    				kraj="PO";
    				break;
    		case 7: System.out.println("Výsledky volieb v Košickom kraji:");
    				kraj="KE";
    				break;
    		}
    		for (Kandidat kandidat :kandidati) {
    			System.out.println(kandidat.getMeno()+ ": " + kandidat.getPocetHlasov_v_kraji(kraj));
    		}
    	}
    }
    
    public void vypisVysledky_v_stranach() {
    	String strana=null;
    	System.out.println("\nVýsledky jednotlivých kandidátov v jednotlivých stranách:");
    	for (int i=0;i<20;i++) {
    		System.out.println("\n");
    		switch(i) {
    	    case 0: strana = "OĽANO"; break;
    	    case 1: strana = "KDH"; break;
    	    case 2: strana = "SaS"; break;
    	    case 3: strana = "Hlas-SD"; break;
    	    case 4: strana = "SME RODINA"; break;
    	    case 5: strana = "Progresívne Slovensko"; break;
    	    case 6: strana = "ZA ĽUDÍ"; break;
    	    case 7: strana = "Republika"; break;
    	    case 8: strana = "Nezávislý kandidát"; break;
    	    case 9: strana = "Strana zelených"; break;
    	    case 10: strana = "Ľudová strana Naše Slovensko"; break;
    	    case 11: strana = "Most-Híd"; break;
    	    case 12: strana = "Za občanov Slovenska"; break;
    	    case 13: strana = "STAROSTOVIA"; break;
    	    case 14: strana = "SDKÚ-DS"; break;
    	    case 15: strana = "ĽUD"; break;
    	    case 16: strana = "Vlasť"; break;
    	    case 17: strana = "Kresťanská únia"; break;
    	    case 18: strana = "Smer-SD"; break;
    	    case 19: strana = "Zmena zdola"; break;
    		}
    		System.out.println(strana + ": ");
    		for (Kandidat kandidat :kandidati) {
    			System.out.println(kandidat.getMeno()+ ": " + kandidat.getPocetHlasov_v_strane(strana));
    		}
    	}
    }
    public void vypisKandidatov() {
    	System.out.println("Prezidentskí kandidáti:");
    	for (Kandidat kandidat: kandidati) {
    		System.out.println(kandidat.getMeno()+kandidat.getInfo_o_kandidatovi());
    	}
    	System.out.println();
    }
}